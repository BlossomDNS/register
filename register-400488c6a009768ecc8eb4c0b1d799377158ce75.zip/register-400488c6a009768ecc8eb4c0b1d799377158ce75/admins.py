#Admin accounts
class Admin:
    def __init__(self, username, password, id):
        self.id = id
        self.username = username
        self.password = password